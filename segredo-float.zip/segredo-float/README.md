# Segredo Float

Botão flutuante + painel (ESP Linhas / Through Wall) para Android.

## Como gerar o APK (pelo celular)

1. Crie um repositório no GitHub chamado `segredo-float` (Public).
2. Faça upload de **todos** os arquivos desta pasta.
3. Vá em **Actions** → rode o workflow **Build APK**.
4. Quando terminar, baixe o artefato `segredo-float-apk`.
5. Instale o `.apk` no celular.

## Uso

1. Abra o app uma vez e permita **Sobrepor a outros apps**.
2. O botão rosa **SA** aparece.
3. Arraste para mover. Toque para abrir o painel.
4. Switches: ESP Linhas e Through Wall (por enquanto só visual; depois ligamos no Virtual).
