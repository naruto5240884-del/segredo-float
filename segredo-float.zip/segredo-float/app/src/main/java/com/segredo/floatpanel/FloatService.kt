package com.segredo.floatpanel

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var isPanelOpen = false

    private var espLines = true
    private var throughWall = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        showBubble()
    }

    private fun startForegroundNotification() {
        val channelId = "float_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Flutuante", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Segredo Float ativo")
            .setContentText("Toque no botão SA")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    private fun showBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()

        val bubble = TextView(this).apply {
            text = "SA"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E91E63"))
            }
        }

        val params = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 200
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(bubble, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(event.rawX - initialTouchX) < 12 &&
                        abs(event.rawY - initialTouchY) < 12) {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubble, params)
        bubbleView = bubble
    }

    private fun togglePanel() {
        if (isPanelOpen) {
            panelView?.let { windowManager.removeView(it) }
            panelView = null
            isPanelOpen = false
        } else {
            showPanel()
            isPanelOpen = true
        }
    }

    private fun showPanel() {
        val density = resources.displayMetrics.density
        val width = (280 * density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E6121212"))
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "SEGREDO AZUL • PAINEL"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        layout.addView(title)

        val swLines = Switch(this).apply {
            text = "ESP Linhas"
            isChecked = espLines
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                espLines = checked
            }
        }
        layout.addView(swLines)

        val swWall = Switch(this).apply {
            text = "Through Wall"
            isChecked = throughWall
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                throughWall = checked
            }
        }
        layout.addView(swWall)

        val btnClose = Button(this).apply {
            text = "Fechar Painel"
            setOnClickListener { togglePanel() }
        }
        layout.addView(btnClose)

        val btnStop = Button(this).apply {
            text = "Encerrar Flutuante"
            setOnClickListener { stopSelf() }
        }
        layout.addView(btnStop)

        val params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        windowManager.addView(layout, params)
        panelView = layout
    }

    override fun onDestroy() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy()
    }
}
